#!/bin/bash

name=shrikantnarute

echo "my name is $name"
echo "what is your channel name?"
read channel
echo "Do Subscrib to my $channel channel"


