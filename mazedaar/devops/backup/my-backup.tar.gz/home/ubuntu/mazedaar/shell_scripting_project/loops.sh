#!/bin/bash

dir=/home/ubuntu/mazedaar/shell_scripting_project/*.*

for files in $dir
do
	echo $files
done
