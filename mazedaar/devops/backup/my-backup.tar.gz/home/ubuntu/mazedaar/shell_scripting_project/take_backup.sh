#!/bin/bash

src=/home/ubuntu/mazedaar/shell_scripting_project
tgt=/home/ubuntu/mazedaar/devops/backup

echo "Backup Started"

tar -cvf $tgt/my-backup.tar.gz $src

echo "Backup Completed"

