#!/bin/bash

sudo apt install $1 -y
