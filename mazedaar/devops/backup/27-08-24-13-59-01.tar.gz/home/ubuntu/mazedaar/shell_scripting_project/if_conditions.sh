#!/bin/bash

name=shrikantnarute
val=1

if [ $val -eq 2 ] 
then
	echo "Yes, $name is logged in"
else
	echo "val is different"
fi


